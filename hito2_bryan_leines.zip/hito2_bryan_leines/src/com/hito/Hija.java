package com.hito;

public class Hija extends Padre {

	public Hija(String texto, int numero) {
		super(texto, numero);
		// TODO Auto-generated constructor stub
	}

	public String getTexto(String Texto){
		return Texto="Hola";
	}
}
