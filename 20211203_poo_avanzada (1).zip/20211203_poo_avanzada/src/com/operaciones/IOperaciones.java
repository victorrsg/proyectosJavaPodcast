package com.operaciones;

public interface IOperaciones {

	public void nadar();
	public String respirar();
}
